/** Next.js configuration (silence root inference warning) */
/** @type {import('next').NextConfig} */
module.exports = {
  turbopack: {
    root: __dirname,
  },
};

